<?php

use \WILCITY_SC\SCHelpers;
use WilokeListingTools\Framework\Helpers\WPML;

$atts = shortcode_atts(
	[
		'TYPE'              => 'LISTINGS',
		'post_type'         => 'listing',
		'orderby'           => '',
		'posts_per_page'    => 6,
		'listing_cats'      => '',
		'listing_locations' => '',
		'listing_tags'      => '',
		'bg_color'          => '#ffffff',
		'style'             => 'grid'
	],
	$atts
);
if (!trait_exists('WILCITY_APP\Controllers\JsonSkeleton')) {
	return '';
}

$aArgs = SCHelpers::parseArgs($atts);
$aArgs = WPML::addFilterLanguagePostArgs($aArgs);

$query = new WP_Query($aArgs);
if (!$query->have_posts()) {
	wp_reset_postdata();

	return '';
}
$aResponse = [];
while ($query->have_posts()) {
	$query->the_post();
	$aListing = apply_filters('wilcity/mobile/render_listings_on_mobile', $atts, $query->post);
	$aResponse[] = $aListing;
}
wp_reset_postdata();

echo '%SC%' . base64_encode(json_encode(
		[
			'oSettings' => \WILCITY_APP\Helpers\AppHelpers::removeUnnecessaryParamOnApp($atts),
			'TYPE'      => $atts['TYPE'],
			'oResults'  => $aResponse,
			'oViewMore' => \WILCITY_APP\Helpers\AppHelpers::getViewMoreArgs($atts),
		]
	)) . '%SC%';

return '';
