<?php

namespace WILCITY_APP\Controllers;


class FirebaseController {
	public function __construct() {
//		add_filter('wilcity/filter/firebase/delete/msg', array($this, 'deleteMsg'), 10, 2);
	}

	public function deleteMsg($status, $firebaseID){

	}
}