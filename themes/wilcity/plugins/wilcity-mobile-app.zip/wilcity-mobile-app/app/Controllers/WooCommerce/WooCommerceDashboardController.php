<?php

namespace WILCITY_APP\Controllers\WooCommerce;

use WILCITY_APP\Controllers\WooCommerceController;

class WooCommerceDashboardController extends WooCommerceController
{
}
