<?php

namespace WILCITY_APP\Controllers\WooCommerce;

use WC_Product_Factory;
use WILCITY_APP\Controllers\WooCommerce\Cart\VariationValidation;
use WILCITY_APP\Controllers\WooCommerce\Cart\WooCart;
use WILCITY_APP\Controllers\WooCommerceController;
use WILCITY_APP\Helpers\App;

class WooCommerceCartController extends WooCommerceController
{
	private $aVariations;
	private $aAttributes;
	private $quantity;
	private $isDeduct    = false;
	private $variationID = 0;

	public function __construct()
	{
		add_action('rest_api_init', function () {
			register_rest_route(WILOKE_PREFIX . '/' . WILOKE_MOBILE_REST_VERSION, '/wc/my-cart', [
				'methods'             => 'GET',
				'callback'            => [$this, 'getMyCart'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/' . WILOKE_MOBILE_REST_VERSION, '/wc/add-to-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'addProductToCart'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/' . WILOKE_MOBILE_REST_VERSION, '/wc/deduct-to-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'deductProductsToCart'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/' . WILOKE_MOBILE_REST_VERSION, '/wc/remove-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'removeCartItem'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/v2', '/wc/my-cart', [
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => [$this, 'getMyCart']
			]);

			register_rest_route(WILOKE_PREFIX . '/v2', '/wc/add-to-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'addProductToCart'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/v2', '/wc/deduct-to-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'deductProductsToCart'],
				'permission_callback' => '__return_true'
			]);

			register_rest_route(WILOKE_PREFIX . '/v2', '/wc/remove-cart', [
				'methods'             => 'POST',
				'callback'            => [$this, 'removeCartItem'],
				'permission_callback' => '__return_true'
			]);
		});
	}

	/**
	 * @param \WP_REST_Request $oRequest
	 *
	 * @return array|bool
	 */
	private function verifyAddToCart(\WP_REST_Request $oRequest)
	{
		$oToken = $this->verifyPermanentToken();
		if (!$oToken) {
			return $this->tokenExpiration();
		}

		$oToken->getUserID();
		$this->userID = $oToken->userID;
		$this->productID = $oRequest->get_param('id');
		$this->quantity = $oRequest->get_param('quantity');
		$this->oProduct = new \WC_Product($this->productID);

		if (get_post_type($this->productID) !== 'product') {
			return [
				'status' => 'error',
				'msg'    => esc_html__('This product does not exists', 'wilcity-mobile-app')
			];
		}

		return true;
	}

	public function removeCartItem(\WP_REST_Request $oRequest)
	{
		$oToken = $this->verifyPermanentToken();
		if (!$oToken) {
			return $this->tokenExpiration();
		}

		return App::get('WooCart')->reset()
			->setCartKey($oRequest->get_param('key'))
			->removeCart();
	}

	public function deductProductsToCart(\WP_REST_Request $oRequest)
	{
		$aStatus = $this->verifyAddToCart($oRequest);
		if (isset($aStatus['status']) && $aStatus['status'] === 'error') {
			return $aStatus;
		}

		/**
		 * @var App::get('WooCart') WILCITY_APP\Controllers\WooCommerce\Cart\WooCart
		 */
		return App::get('WooCart')->reset()
			->setProduct($this->oProduct)
			->setUserId($this->userID)
			->setMode('deduceOne')
			->addToCart();
	}

	public function addProductToCart(\WP_REST_Request $oRequest)
	{
		$aResponse = $this->verifyAddToCart($oRequest);
		if (isset($aResponse['status']) && $aResponse['status'] === 'error') {
			return $aResponse;
		}

		$mode = $oRequest->get_param('mode');
		$mode = empty($mode) ? 'specifyQuantity' : $mode;
		$type = \WC_Product_Factory::get_product_type($this->oProduct->get_id());

		switch ($type) {
			case 'variation':
			case 'variable':
				$oVariationValidation = new VariationValidation();
				try {
					$aResponse = $oVariationValidation->setProduct($this->oProduct)
						->setVariationId($oRequest->get_param('variationID'))
						->setAttributes($oRequest->get_param('attributes'))
						->setQuantity($this->quantity)
						->validate();

					if ($aResponse['status'] == 'error') {
						return $aResponse;
					}

					$aResponse = App::get('WooCart')->reset()
						->setProduct($this->oProduct)
						->setUserId($this->userID)
						->setVariationId($oRequest->get_param('variationID'))
						->setMode($mode)
						->setQuantity($this->quantity)
						->setVariations($aResponse['variations'])
						->addToCart();
				}
				catch (\Exception $e) {
					return [
						'status' => 'error',
						'msg'    => $e->getMessage()
					];
				}
				break;
			case 'simple':
				$aResponse = App::get('WooCart')->reset()
					->setProduct($this->oProduct)
					->setUserId($this->userID)
					->setMode($mode)
					->setQuantity($this->quantity)
					->addToCart();

				break;
			default:
				$aResponse = [
					'status' => 'error',
					'msg'    => sprintf(
						wilcityAppGetLanguageFiles('noSupportedProductType'),
						$type
					)
				];
				break;
		}

		return $aResponse;
	}

	public function getMyCart()
	{
		$oToken = $this->verifyPermanentToken();
		if (!$oToken) {
			return $this->tokenExpiration();
		}
		$oToken->getUserID();
		$aCartItems = $this->getMyCartSkeleton($oToken->userID);

		if (empty($aCartItems)) {
			return [
				'status'     => 'success',
				'msg'        => 'emptyCart',
				'oCartItems' => []
			];
		}

		return [
			'status'     => 'success',
			'oCartItems' => $aCartItems
		];
	}
}
