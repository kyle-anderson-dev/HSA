(function($) {
    $(function() {
        
        
    });//$(function() {
})(jQuery);