<?php

namespace WILCITY_ELEMENTOR\Registers;

use Elementor\Plugin;

class Init
{
	public function __construct()
	{
		add_action('elementor/editor/before_enqueue_scripts', [$this, 'adminScripts']);
		add_action('elementor/widgets/widgets_registered', [$this, 'registerWidgets']);
		add_action('elementor/controls/controls_registered', [$this, 'registerSelectTwoAjaxControl']);
	}

	public function registerSelectTwoAjaxControl()
	{
		$controls_manager = \Elementor\Plugin::$instance->controls_manager;
		$controls_manager->register_control('wil_select2_ajax', new SelectTwoAjaxControl());
	}

	public function adminScripts()
	{
		if (isset($_GET['action']) && $_GET['action'] === 'elementor') {
			wp_enqueue_style('wilcity-elementor-style', WILCITY_EL_SOURCE_URL . 'css/elementor-style.css', [],
				WILCITY_EL_VERSION);
		}
	}

	/**
	 * Register Widget
	 *
	 * @since  1.0.0
	 *
	 * @access private
	 */
	public function registerWidgets()
	{
		Plugin::instance()->widgets_manager->register_widget_type(new PostTypes());
		Plugin::instance()->widgets_manager->register_widget_type(new Heading());
		Plugin::instance()->widgets_manager->register_widget_type(new SearchForm());
		Plugin::instance()->widgets_manager->register_widget_type(new Hero());
		Plugin::instance()->widgets_manager->register_widget_type(new Grid());
		Plugin::instance()->widgets_manager->register_widget_type(new NewGrid());
		Plugin::instance()->widgets_manager->register_widget_type(new EventsGrid());
		Plugin::instance()->widgets_manager->register_widget_type(new RestaurantListings());
		Plugin::instance()->widgets_manager->register_widget_type(new TermBoxes());
		Plugin::instance()->widgets_manager->register_widget_type(new RectangleTermBoxes());
		Plugin::instance()->widgets_manager->register_widget_type(new ModernTermBoxes());
		Plugin::instance()->widgets_manager->register_widget_type(new MasonryTermBoxes());
		Plugin::instance()->widgets_manager->register_widget_type(new ListingsSlider());
		Plugin::instance()->widgets_manager->register_widget_type(new EventsSlider());
		Plugin::instance()->widgets_manager->register_widget_type(new Pricing());
		Plugin::instance()->widgets_manager->register_widget_type(new BoxIcon());
		Plugin::instance()->widgets_manager->register_widget_type(new Testimonials());
		Plugin::instance()->widgets_manager->register_widget_type(new Canvas());
		Plugin::instance()->widgets_manager->register_widget_type(new ContactUs());
		Plugin::instance()->widgets_manager->register_widget_type(new IntroBox());
		Plugin::instance()->widgets_manager->register_widget_type(new TeamIntroSlider());
		Plugin::instance()->widgets_manager->register_widget_type(new ListingTabs());
		Plugin::instance()->widgets_manager->register_widget_type(new ListingsTabs());
		Plugin::instance()->widgets_manager->register_widget_type(new CustomLogin());
		Plugin::instance()->widgets_manager->register_widget_type(new AuthorSlider());
	}
}
