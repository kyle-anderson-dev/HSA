<?php
return [
    'UTC+7' => 'Ho Chi Minh'
];