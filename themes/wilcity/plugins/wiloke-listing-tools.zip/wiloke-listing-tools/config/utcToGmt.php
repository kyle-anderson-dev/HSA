<?php
return [
    'UTC+0' => 'UTC',
    'UTC+7' => 'Asia/Ho_Chi_Minh',
    'UTC+8' => 'Asia/Hong_Kong',
    'UTC+6' => 'Asia/Thimphu',
];
