<?php
return [
	'403' => esc_html__('You do not permission to access this page', 'wiloke-listing-tools')
];