<?php

namespace WilokeListingTools\Framework\Helpers;

class Logger
{
    public static function writeLog($log)
    {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }
}
