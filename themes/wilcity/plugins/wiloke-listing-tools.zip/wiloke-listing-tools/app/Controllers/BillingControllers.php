<?php

namespace WilokeListingTools\Controllers;

use WilokeListingTools\Framework\Helpers\GetSettings;
use WilokeListingTools\Framework\Helpers\GetWilokeSubmission;
use WilokeListingTools\Framework\Routing\Controller;
use WilokeListingTools\Frontend\User;
use WilokeListingTools\Models\InvoiceModel;
use WilokeListingTools\Models\PaymentMetaModel;
use WilokeListingTools\Models\PaymentModel;
use WilokeListingTools\Models\RemainingItems;
use WilokeListingTools\Models\UserModel;

class BillingControllers extends Controller
{
    public function __construct()
    {
//        add_action('wp_ajax_wilcity_post_type_plans', [$this, 'fetchPostTypePlans']);
//        add_action('wp_ajax_wilcity_fetch_billing_type', [$this, 'getBillingType']);
    }
    
    
    
    
    
}
