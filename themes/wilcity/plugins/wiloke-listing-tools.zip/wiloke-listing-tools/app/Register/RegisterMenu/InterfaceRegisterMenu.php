<?php

namespace WilokeListingTools\Register\RegisterMenu;

interface InterfaceRegisterMenu
{
    public function registerMenu();
    
    public function registerSettingArea();
}
