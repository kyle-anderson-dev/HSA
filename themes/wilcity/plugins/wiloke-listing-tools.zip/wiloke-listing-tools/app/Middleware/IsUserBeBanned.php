<?php

namespace WilokeListingTools\Middleware;


use WilokeListingTools\Framework\Routing\InterfaceMiddleware;

class IsUserBeBanned implements InterfaceMiddleware {
	public $msg;
	public function handle( array $aOptions ) {

	}
}