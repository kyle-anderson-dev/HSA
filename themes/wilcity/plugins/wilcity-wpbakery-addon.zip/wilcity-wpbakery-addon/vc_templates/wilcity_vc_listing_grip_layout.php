<?php
include WILCITY_VC_SC_DIR . 'vc_templates/wilcity_vc_grid.php';
