<?php
return [
    'TYPE' => 'AUTHOR_SLIDER',
    'role__in' => 'administrator,contributor',
    'orderby' => 'post_count',
    'number' => 8,
    '_id' => '',
    'wrapper_id' => '',
    'extra_class' => ''
];
