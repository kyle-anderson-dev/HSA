<?php
return [
  'TYPE'         => 'SEARCH_FORM',
  '_id'          => '',
  'is_using_tab' => 'no',
  'items'        => [],
  'extra_class'  => '',
  'style'        => 'default'
];
