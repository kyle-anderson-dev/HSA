<?php
return [
  'TYPE'                 => 'WAVE',
  '_id'                  => '',
  'heading'              => '',
  'description'          => '',
  'desc'                 => '',
  'btn_group'            => [],
  'left_gradient_color'  => '#f06292',
  'right_gradient_color' => '#f97f5f',
  'extra_class'          => ''
];
