<?php
return [
	'_id'                        => '',
	'wrapper_id'                 => '',
	'image_size'                 => 'large',
	'maximum_posts_on_lg_screen' => 'col-md-3',
	'maximum_posts_on_md_screen' => 'col-md-3',
	'maximum_posts_on_sm_screen' => 'col-md-12',
	'post_types'                 => '',
	'heading'                    => '',
	'heading_color'              => '',
	'desc_color'                 => '',
	'desc'                       => '',
	'header_desc_text_align'     => '',
	'css'                        => '',
	'extra_class'                => ''
];
